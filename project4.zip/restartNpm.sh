cd ../
cd blog-server/
npm start